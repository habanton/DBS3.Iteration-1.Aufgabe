import stringdist
import csv
import re
import random
import ast
import psycopg2
import numpy as np
from os import path
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from pylab import *
from PIL import Image
#Baut die Verbindung zur Datenbank 'Election' auf
try:
	conn = psycopg2.connect("host='localhost' user='postgres' password='postgres' dbname='Election'")

except:
	print "connection failed"

cur = conn.cursor()

cur.execute("""SELECT htnr,Text FROM Hashtag """)
reader = cur.fetchall()


output = open("Trump.csv","wb")
output2 = open("Hillary.csv","wb")
output3 = open("America.csv","wb")


writer=csv.writer(output,delimiter=";")
writer2=csv.writer(output2,delimiter=";")
writer3=csv.writer(output3,delimiter=";")
a="Trump"
b="Hillary"
c="America"
headers =[a,b,c]
alist=[]
blist=[]
clist=[]
for row in reader:
	reihe=re.sub(r'#',r'',row[1])
	if stringdist.rdlevenshtein(a,reihe)>stringdist.rdlevenshtein(b,reihe) and stringdist.rdlevenshtein(c,reihe):
		alist.append(row[1])
		mean=0
		asecondlist=[]
		for i in range(len(alist)):
			asecondlist.append(stringdist.rdlevenshtein(a,alist[i]))
		mean=(sum(asecondlist))/len(asecondlist)
		a=alist[asecondlist.index(min(asecondlist,key=lambda x:abs(x-mean)))]
	elif stringdist.rdlevenshtein(b,reihe)>stringdist.rdlevenshtein(c,reihe):
		blist.append(row[1])
		mean=0
		bsecondlist=[]
		for i in range(len(blist)):
			bsecondlist.append(stringdist.rdlevenshtein(b,blist[i]))
		mean=(sum(bsecondlist))/len(bsecondlist)
		b=blist[bsecondlist.index(min(bsecondlist,key=lambda x:abs(x-mean)))]
	else:
		clist.append(row[1])
		mean=0
		csecondlist=[]
		for i in range(len(clist)):
			csecondlist.append(stringdist.rdlevenshtein(c,clist[i]))
		mean=(sum(csecondlist))/len(csecondlist)
		c=clist[csecondlist.index(min(csecondlist,key=lambda x:abs(x-mean)))]
lena=len(alist)
lenb=len(blist)
lenc=len(clist)
for i in range(max(lena,lenb,lenc)):
	if i<lena:
		writer.writerow([alist[i]])
	if i<lenb:
		writer2.writerow([blist[i]])
	if i<lenc:
		writer3.writerow([clist[i]])
output.close()
output2.close()
output3.close()

	
conn.commit()
cur.close()
conn.close()	
cluster=[alist,blist,clist]
count=1
for d in range(-1,(len(cluster))):
	text=str(cluster[d])+""
	header=str(headers[d])+""
	e=path.dirname('_file_')
	bild=np.array(Image.open(path.join(e,"twitter.png")))
	wordcloud=WordCloud(background_color='white',mask=bild).generate(text)
	#plt.figure(figsize=(20,10),facecolor='k')
	plt.imshow(wordcloud,interpolation='bilinear')
	plt.title(header)
	plt.axis("off")
	ap=subplot(1,3,count)
	plt.subplots_adjust(hspace=1)
	if(count<3):
		count=count+1
	else:
		count=3
plt.savefig("K-Mean")

